Syntax highlighting and config files for working with Avro files in various text editors.
