# avro三方库说明
## 功能简介
avro是指数据序列化的系统，有丰富的数据结构类型、快速可压缩的二进制数据形式。
## 使用约束
- IDE版本：DevEco Studio 3.1 Beta2
- SDK版本：ohos_sdk_public 3.2.11.9 (API Version 9 Release)
- 三方库版本：release-1.11.1
- 当前适配的功能：提供数据的序列化框架
- [Apache License](https://github.com/apache/avro/blob/master/LICENSE.txt)

## 集成方式
+ [应用hap包集成](docs/hap_integrate.md)