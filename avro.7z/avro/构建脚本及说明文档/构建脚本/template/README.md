# 如何使用 lycium

## HPKBUILD 文件的格式
请项目阅读, HPKBUILD 文件.

## SHA512SUM的格式
SHA512SUM 记录库的压缩包的 sha512sum 值, 以及库对应的 patch 文件的sha512值.